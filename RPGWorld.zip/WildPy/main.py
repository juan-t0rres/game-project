import pygame, sys, time
from scripts.textures import *
from scripts.globals import *
from scripts.mapEngine import *
#RBG

pygame.init()

cSec=0
cFrame=0
fps=0

fpsFont=pygame.font.Font("graphics\\font.otf", 20)

terrain=MapEngine.loadMap("maps\\mainLand.map")
Sky=pygame.Surface(pygame.image.load("graphics\\sky.png").get_size(),pygame.HWSURFACE)
Sky.blit(pygame.image.load("graphics\\sky.png"), (0,0))

def create_window():
    global window, window_h, window_w, window_title
    window_w, window_h = 800,600
    window_title="RPGWorld"
    pygame.display.set_caption(window_title)
    window = pygame.display.set_mode((window_w,window_h), pygame.HWSURFACE)

def show_fps():
    fps_overlay= fpsFont.render(str(fps), True, (244,234,0))
    window.blit(fps_overlay,(0,0))
def count_fps():
    global cSec, cFrame, fps, dtime

    if cSec==time.strftime("%S"):
        cFrame+=1
    else:
        fps=cFrame
        cFrame=0
        cSec=time.strftime("%S")
        if fps>0:
            dtime=1/fps

create_window()
running= True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                Globals.d_camera=1
            elif event.key == pygame.K_s:
                Globals.d_camera=2
            elif event.key == pygame.K_a:
                Globals.d_camera=3
            elif event.key == pygame.K_d:
                Globals.d_camera=4
        elif event.type==pygame.KEYUP:
            Globals.d_camera=0

    #logic
    if Globals.d_camera==1:
        Globals.camera_y+=100*dtime
    elif Globals.d_camera==2:
        Globals.camera_y-=100*dtime
    elif Globals.d_camera==3:
        Globals.camera_x+=100*dtime
    elif Globals.d_camera==4:
        Globals.camera_x-=100*dtime

    #render
    window.blit(Sky,(0,0))
    window.blit(terrain,(Globals.camera_x,Globals.camera_y))

    show_fps()

    pygame.display.update()
    count_fps()

pygame.quit()
sys.exit()
