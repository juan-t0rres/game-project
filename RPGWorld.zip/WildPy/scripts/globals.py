class Globals:
    camera_x=0
    camera_y=0
    d_camera=0

