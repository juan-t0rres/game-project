import pygame
from scripts.textures import *

class MapEngine:

    def addTile(tile,pos,addTo):
        addTo.blit(tile,(pos[0]*Tiles.size,pos[1]*Tiles.size))

    def loadMap(file):
        with open(file,"r") as mapfile:
            mapData=mapfile.read().split("-")
        mapSize=mapData.pop().split(",")
        mapSize[0]=int(mapSize[0])*Tiles.size
        mapSize[1]=int(mapSize[1])*Tiles.size

        tiles=[]

        for tile in range(len(mapData)):
            mapData[tile]=mapData[tile].replace("\n","")
            tiles.append(mapData[tile].split(":"))
        for tile in tiles:
            tile[0]=tile[0].split(",")
            pos=tile[0]
            for p in pos:
                pos[pos.index(p)]=int(p)
            tiles[tiles.index(tile)]=(pos,tile[1])

        terrain=pygame.Surface(mapSize,pygame.HWSURFACE)

        for tile in tiles:
            if tile[1] in Tiles.dict:
                MapEngine.addTile(Tiles.dict[tile[1]],tile[0],terrain)
        return terrain
