import pygame


pygame.init()

class Tiles:
    size=32
    def Load_Texture(file,size):
        bitmap=pygame.image.load(file)
        bitmap=pygame.transform.scale(bitmap, (size,size))
        surface = pygame.Surface((size,size),pygame.HWSURFACE|pygame.SRCALPHA)
        surface.blit(bitmap,(0,0))
        return surface
    grass=Load_Texture("graphics\\grass.png",size)
    stone=Load_Texture("graphics\\water.png",size)
    water=Load_Texture("graphics\\stone.png",size)


    dict = {"1" : grass,"2": stone,"3": water}
